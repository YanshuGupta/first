package com.capgemini.capstore.main.beans;

public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics
}
