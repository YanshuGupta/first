package com.capgemini.capstore.main.beans;

public enum ReturnStatus {
	Applied, Approved, Rejected
}
