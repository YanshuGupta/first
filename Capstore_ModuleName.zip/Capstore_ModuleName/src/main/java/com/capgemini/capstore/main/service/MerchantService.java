package com.capgemini.capstore.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.dao.CapStoreMerchant;

@Service
public class MerchantService implements IMerchantService{

	@Autowired
	CapStoreMerchant merchantRepo;
}
