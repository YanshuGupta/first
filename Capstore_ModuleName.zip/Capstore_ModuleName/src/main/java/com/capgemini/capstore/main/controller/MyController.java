package com.capgemini.capstore.main.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.Product;
import com.capgemini.capstore.main.service.IMerchantService;

@RestController
public class MyController {

	@Autowired
	IMerchantService service;
	
	@RequestMapping(value="/")
	public String homePage() {
		return "HomePage";
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/addProduct")
	public String addProduct(@Valid @RequestBody Product product, @PathVariable double productPrice, @PathVariable int productQuantity) {
		
		System.out.println(product);
		System.out.println(productPrice);
		System.out.println(productQuantity);
		
		return "Successfull Add Product";
	}

}
