package com.capgemini.capstore.main.beans;

public enum DeliveryStatus {
	Ordered, Shipped, OutForDelivery, Delivered
}
