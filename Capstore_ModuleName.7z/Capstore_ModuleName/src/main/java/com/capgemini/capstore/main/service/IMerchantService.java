package com.capgemini.capstore.main.service;

import java.util.Optional;

import com.capgemini.capstore.main.beans.Merchant;
import com.capgemini.capstore.main.beans.User;

public interface IMerchantService {

	Optional<User> ValidateLogIn(User user);

	Merchant getMerchant(int merchantId);

}
