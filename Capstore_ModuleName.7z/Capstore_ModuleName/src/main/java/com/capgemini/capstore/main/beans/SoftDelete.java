package com.capgemini.capstore.main.beans;

public enum SoftDelete {
	Activated, Deactivated
}
