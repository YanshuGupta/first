package com.capgemini.capstore.main.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.Merchant;
import com.capgemini.capstore.main.beans.User;
import com.capgemini.capstore.main.dao.CapStoreMerchant;
import com.capgemini.capstore.main.dao.CapStoreUser;

@Service
public class MerchantService implements IMerchantService{

	@Autowired
	CapStoreMerchant merchantRepo;
	
	@Autowired
	CapStoreUser userRepo;

	@Override
	public Optional<User> ValidateLogIn(User user) {
		if(userRepo.findById(user.getEmailId()) == null) {
			userRepo.save(user);
			return userRepo.findById(user.getEmailId());
		}
		return null;
	}

	@Override
	public Merchant getMerchant(int merchantId) {
		return merchantRepo.getOne(merchantId);
	}
}
