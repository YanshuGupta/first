package com.capgemini.capstore.main.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.Product;
import com.capgemini.capstore.main.service.IMerchantService;

@RestController
public class MyController {

	@Autowired
	IMerchantService service;

	@RequestMapping(method = RequestMethod.POST, value = "/getProduct/{productId}/{merchantEmail}")
	public Product getProduct(@PathVariable int productId, @PathVariable String merchantEmail,
			HttpServletRequest request) {

		return service.getProduct(productId, merchantEmail);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/addProduct/{merchantEmail}")
	public String addProduct(@RequestBody Product product, @PathVariable String merchantEmail) {

		service.addProduct(product, merchantEmail);
		return "MerchantHome";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/updateProduct/{merchantEmail}")
	public String updateProduct(@RequestBody Product product, @PathVariable String merchantEmail) {

		service.updateProduct(product, merchantEmail);
		return "MerchantHome";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/removeProduct/{productId}/{merchantEmail}")
	public String removeProduct(@PathVariable int productId, @PathVariable String merchantEmail) {

		service.removeProduct(productId, merchantEmail);
		return "success";

	}

}
