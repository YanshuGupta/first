package com.capgemini.capstore.main.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.beans.Order;
import com.capgemini.capstore.main.service.IMerchantService;

@RestController
public class MyController {

	@Autowired
	IMerchantService service;
	

	@RequestMapping(method = RequestMethod.GET, value = "/getAllOrders/{customerId}")
	public List<Order> getAllOrders(@PathVariable String customerId) {
		return service.getAllOrders(customerId);
		//return new ModelAndView("error", "order", order);
	}

	
	@RequestMapping(method = RequestMethod.GET, value = "/invoice/{orderId}/{customerId}")
	public Order getInvoice(@PathVariable int orderId, @PathVariable String customerId, HttpServletRequest request) {
		
		return service.findOrder(customerId,orderId);
	}

	
}
