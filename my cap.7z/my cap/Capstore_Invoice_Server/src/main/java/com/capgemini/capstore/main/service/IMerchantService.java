package com.capgemini.capstore.main.service;

import java.util.List;

import com.capgemini.capstore.main.beans.Order;

public interface IMerchantService {

	Order findOrder(String customerId, int orderId);

	List<Order> getAllOrders(String customerId);

}
