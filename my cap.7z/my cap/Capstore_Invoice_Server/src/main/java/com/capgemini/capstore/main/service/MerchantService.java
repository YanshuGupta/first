package com.capgemini.capstore.main.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.main.beans.Order;
import com.capgemini.capstore.main.dao.CapStoreMerchant;
import com.capgemini.capstore.main.dao.CapStoreOrder;

@Service
public class MerchantService implements IMerchantService {
	
	@Autowired
	CapStoreMerchant merchantRepo;
	
	@Autowired
	CapStoreOrder orderRepo;
	
	@Override
	public Order findOrder(String customerId, int orderId) {
		
		Order order = orderRepo.findById(orderId).get();
		
		if(order.getCustomer().getCustomerEmail().equals(customerId)) {
			return order;
		}
		return null;
	}

	@Override
	public List<Order> getAllOrders(String userId) {
		
		return orderRepo.findByMerchant(merchantRepo.findByMerchantEmail(userId));
	}

}
