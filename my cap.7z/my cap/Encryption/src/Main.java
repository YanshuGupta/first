public class Main {
	public static void main(String[] args) {
		MD5 encryption = new MD5();
		System.out.println(encryption.encryptText("Yanshu8979", 5));
	}
}
