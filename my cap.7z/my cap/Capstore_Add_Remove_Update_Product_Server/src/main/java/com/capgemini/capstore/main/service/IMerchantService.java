package com.capgemini.capstore.main.service;

import java.util.List;

import javax.validation.Valid;

import com.capgemini.capstore.main.beans.Product;

public interface IMerchantService {

	Product addProduct(Product product, String merchantEmail);

	Product updateProduct(Product product, String merchantEmail);

	Product getProduct(int productId, String merchantEmail);

	boolean removeProduct(int productId, String merchantEmail);

	List<Product> getAllProducts(String merchantEmail);

	


}
