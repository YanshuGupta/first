package com.capgemini.capstore;

import com.capgemini.capstore.beans.Product;

public class RestResponseRemoveProduct {
	
	private int productId;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public RestResponseRemoveProduct() {
		super();
		// TODO Auto-generated constructor stub
	}

		

}
