package com.capgemini.capstore;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.capgemini.capstore.beans.Product;

@Controller
public class WelcomeController {

	private Product tempProduct;
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	@Autowired
	RestTemplate rest;
	// inject via application.properties
	/*
	 * @Value("${welcome.message:test}") private String message = "Hello World";
	 * 
	 * @RequestMapping("/") public String welcome(Map<String, Object> model) {
	 * model.put("message", this.message); return "welcome"; }
	 */

	
	@RequestMapping("/MerchantFeedbackProduct")
	public String MerchantFeedbackProduct(ModelMap map){
		return "MerchantFeedbackProduct";
	}
	
	
//	@RequestMapping(method = RequestMethod.GET, value = "/getAllOrders/{customerId}")
//	public List<Order> getAllOrders(@PathVariable String customerId) {
//		return service.getAllOrders(customerId);
//		//return new ModelAndView("error", "order", order);
//	}
//
//	
//	@RequestMapping(method = RequestMethod.GET, value = "/invoice/{orderId}/{customerId}")
//	public Order getInvoice(@PathVariable int orderId, @PathVariable String customerId, HttpServletRequest request) {
//		
//		return service.findOrder(customerId,orderId);
//	}

	
	@RequestMapping(value="/fileupdatemerchant", method=RequestMethod.POST,produces = "application/json")
	public String updateMerchantProduct(HttpServletRequest request) {
		
		String merchantEmail = "yanshu@gupta.com";
		
		Product product = new Product();
		String productName = request.getParameter("productName");
//		String productImageUrl = request.getParameter("productImageUrl");
		String productCategory = request.getParameter("productCategory");
		String productBrand = request.getParameter("productBrand");
		String productModel = request.getParameter("productModel");
		String productType = request.getParameter("productType");
//		String productFeature = request.getParameter("productFeature");
		double productPrice = Double.parseDouble(request.getParameter("productPrice"));
		
		product.setProductBrand(productBrand);
		product.setProductCategory(productCategory);
		product.setProductFeature("feature");
		product.setProductImageUrl("Image url");
		product.setProductModel(productModel);
		product.setProductName(productName);
		product.setProductType(productType);
		product.setProductPrice(productPrice);
		product.setProductId(tempProduct.getProductId());
		
		System.out.println(product);
		
		RestResponseAddProduct restRes = new RestResponseAddProduct();
		restRes.setProduct(product);

		String str = rest.postForObject("http://localhost:8092/updateProduct/"+merchantEmail, product, String.class);
		//msg -> Product updated success
		return str;
	}
}
