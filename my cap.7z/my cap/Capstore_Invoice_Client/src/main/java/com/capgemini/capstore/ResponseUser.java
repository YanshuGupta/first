package com.capgemini.capstore;

public class ResponseUser {
	
	private RestResponseAddProduct restResponseUser;

	public RestResponseAddProduct getRestResponseUser() {
		return restResponseUser;
	}

	public void setRestResponseUser(RestResponseAddProduct restResponseUser) {
		this.restResponseUser = restResponseUser;
	}

	public ResponseUser() {
		super();
	}
	
	

}
