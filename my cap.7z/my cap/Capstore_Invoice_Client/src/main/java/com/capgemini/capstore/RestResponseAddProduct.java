package com.capgemini.capstore;

import com.capgemini.capstore.beans.Product;

public class RestResponseAddProduct {
	
	private Product product;

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public RestResponseAddProduct() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "RestResponseProduct [product=" + product + "]";
	}

	
	

}
